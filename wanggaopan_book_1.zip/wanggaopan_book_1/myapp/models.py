from django.db import models

# Create your models here.

class Tsmodel(models.Model):
    # 姓名
    name = models.CharField(max_length=20)
    # 价格
    price = models.FloatField()
    # 作者
    zz = models.CharField(max_length=20)






