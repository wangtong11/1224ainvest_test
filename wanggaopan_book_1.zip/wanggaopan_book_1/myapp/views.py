from django.shortcuts import render
from django.shortcuts import render
from rest_framework.viewsets import GenericViewSet
from rest_framework.mixins import CreateModelMixin,ListModelMixin,RetrieveModelMixin,DestroyModelMixin,UpdateModelMixin
from rest_framework.response import Response
# Create your views here.

from myapp.models import Tsmodel
# Create your views here.
from myapp.serializers import DetailSerializer

class Detail(GenericViewSet,ListModelMixin):
    queryset = Tsmodel.objects.all()
    serializer_class = DetailSerializer

#增
class CreateCollege(GenericViewSet,CreateModelMixin):
    queryset = Tsmodel.objects.all()
    serializer_class = DetailSerializer


#删
class DelCollege(GenericViewSet,DestroyModelMixin):
    queryset = Tsmodel.objects.all()
    serializer_class = DetailSerializer

#改
class UpdateCollege(GenericViewSet,UpdateModelMixin):
    queryset = Tsmodel.objects.all()
    serializer_class = DetailSerializer

