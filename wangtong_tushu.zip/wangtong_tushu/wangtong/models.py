from datetime import datetime
from django.db import models

# Create your models here.

class Book_type(models.Model):
    type_name = models.CharField('类别名称',default="",max_length=255,help_text='类别名称')
    desc = models.TextField("类别描述", default="",max_length=255, help_text="类别描述")
    add_time = models.DateTimeField("添加时间", default=datetime.now)

    class Meta:
            verbose_name = "书籍类别"
            verbose_name_plural = verbose_name

    def __str__(self):
        return self.type_name


class Book(models.Model):
    book_name = models.CharField('书名', default="", max_length=255,help_text='书名')
    book_count = models.TextField("内容", default="", max_length=255,help_text="内容")
    image = models.ImageField()
    add_time = models.DateTimeField("添加时间", default=datetime.now)


    class Meta:
        verbose_name = "书名"
        verbose_name_plural = verbose_name

    def __str__(self):
        return self.book_name