from django.contrib import admin
from .models import Book_type,Book
# Register your models here.

class BooktypeAdmin(admin.ModelAdmin):
    list_display = ["book_type","desc","add_time"]
    search_fields = ["book_type"]

