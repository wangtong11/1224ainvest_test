from django.apps import AppConfig


class WangtongConfig(AppConfig):
    name = 'wangtong'
