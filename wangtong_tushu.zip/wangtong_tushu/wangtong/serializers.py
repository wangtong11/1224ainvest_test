from rest_framework import serializers
from django.db.models import Q
from .models import Book

class BooksSerializer(serializers.ModelSerializer):

    class Meta:
        model = Book
        fields = '__all__'



