import django_filters
from django.db.models import Q
from .models import Book


class BookFilter(django_filters.rest_framework.FilterSet):
    '''
    商品过滤的类
    '''
    pricemin = django_filters.NumberFilter(field_name="book", lookup_expr='id')

    def top_category_filter(self, queryset, name, value):
        return queryset.filter(Q(category_id=value) | Q(category__parent_category_id=value) | Q(
            category__parent_category__parent_category_id=value))

    class Meta:
        model = Book
        fields = ['book_name', 'book_rount',]
