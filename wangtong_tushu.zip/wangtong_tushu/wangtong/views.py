from django.shortcuts import render
from guardian import mixins
from rest_framework import viewsets
from .models import Book
from .filter import BookFilter
from .serializers import BooksSerializer
# Create your views here.


class BookViews(mixins.ListModelMixin, mixins.RetrieveModelMixin, viewsets.GenericViewSet):
    queryset = Book.objects.filter(category_type=1)
    serializer_class = BooksSerializer