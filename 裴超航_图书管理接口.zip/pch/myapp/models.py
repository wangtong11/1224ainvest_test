from django.db import models

# Create your models here.

class Tsmodel(models.Model):
    name = models.CharField(max_length=20,null=False)
    author = models.CharField(max_length=20,null=False)
    price = models.FloatField()





