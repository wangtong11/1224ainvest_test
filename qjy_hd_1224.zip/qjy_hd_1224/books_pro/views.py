from django.shortcuts import render
from django.shortcuts import render
from rest_framework.viewsets import GenericViewSet
from rest_framework.mixins import CreateModelMixin,ListModelMixin,RetrieveModelMixin,DestroyModelMixin,UpdateModelMixin
from rest_framework.response import Response
# Create your views here.

from .models import books1
# Create your views here.
from .ser import creSerializer

#查看
class Detail(GenericViewSet,ListModelMixin):
    queryset = books1.objects.all()
    serializer_class = creSerializer


#增加
class CreateCollege(GenericViewSet,CreateModelMixin):
    queryset = books1.objects.all()
    serializer_class = creSerializer



#删除
class DelCollege(GenericViewSet,DestroyModelMixin):
    queryset = books1.objects.all()
    serializer_class = creSerializer


#修改
class UpdateCollege(GenericViewSet,UpdateModelMixin):
    queryset = books1.objects.all()
    serializer_class = creSerializer


